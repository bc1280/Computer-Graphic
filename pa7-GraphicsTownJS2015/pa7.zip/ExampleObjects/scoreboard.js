
var grobjects = grobjects || [];

var scoreboard = undefined;
(function () {
    "use strict";

    var shaderProgram = undefined;
    var buffers = undefined;

    scoreboard = function scoreboard(name, position, size, color) {
        this.name = name;
        this.position = position || [0, 0, 0];
        this.size = size || 0.5;
        this.color = color || [.7, .8, .9];
    }
    scoreboard.prototype.init = function (drawingState) {
        var gl = drawingState.gl;
        // create the shaders once - for all cubes
        if (!shaderProgram) {
            shaderProgram = twgl.createProgramInfo(gl, ["scoreboard-vs", "scoreboard-fs"]);
        }
        if (!buffers) {
            var arrays = {
                vpos: {
                    numComponents: 3,
                    data: [
                        //body
                        //backBottom Triangle
                        -0.35, -0.5, -0.5,
                        0.35, -0.5, -0.5,
                        0.35, 0.5, -0.5,
                        -0.35, -0.5, -0.5,

                        //backTop Triangle
                        0.35, 0.5, -0.5,
                        -0.35, 0.5, -0.5,
                        -0.35, -0.5, 0.5,
                        0.35, -0.5, 0.5,

                        0.35, 0.5, 0.5,
                        -0.35, -0.5, 0.5,
                        0.35, 0.5, 0.5,
                        -0.35, 0.5, 0.5,

                        -0.35, -0.5, -0.5,
                        0.35, -0.5, -0.5,
                        0.35, -0.5, 0.5,
                        -0.35, -0.5, -0.5,

                        0.35, -0.5, 0.5,
                        -0.35, -0.5, 0.5,
                        -0.35, 0.5, -0.5,
                        0.35, 0.5, -0.5,

                        0.35, 0.5, 0.5,
                        -0.35, 0.5, -0.5,
                        0.35, 0.5, 0.5,
                        -0.35, 0.5, 0.5,

                        -0.35, -0.5, -0.5,
                        -0.35, 0.5, -0.5,
                        -0.35, 0.5, 0.5,
                        -0.35, -0.5, -0.5,

                        -0.35, 0.5, 0.5,
                        -0.35, -0.5, 0.5,
                        0.35, -0.5, -0.5,
                        0.35, 0.5, -0.5,

                        0.35, 0.5, 0.5,
                        0.35, -0.5, -0.5,
                        0.35, 0.5, 0.5,
                        0.35, -0.5, 0.5,

                        -0.35, -1.0, .5,
                        -0.35, -0.5, 0.5,
                        -0.35, -0.5, 0.1,

                        -0.35, -1.0, 0.2,
                        -0.35, -1.0, 0.5,
                        -0.35, -0.5, 0.2,


                        -0.35, -1.0, -.5,
                        -0.35, -0.5, -0.5,
                        -0.35, -0.5, -0.2,

                        -0.35, -1.0, -0.2,
                        -0.35, -1.0, -0.5,
                        -0.35, -0.5, -0.2
                    ]
                },
                vnormal: {
                    numComponents: 3,
                    data: [
                        0, 0, -1,
                        0, 0, -1,
                        0, 0, -1,
                        0, 0, -1,

                        0, 0, -1,
                        0, 0, -1,
                        0, 0, 1,
                        0, 0, 1,

                        0, 0, 1,
                        0, 0, 1,
                        0, 0, 1,
                        0, 0, 1,

                        0, -1, 0,
                        0, -1, 0,
                        0, -1, 0,
                        0, -1, 0,

                        0, -1, 0,
                        0, -1, 0,
                        0, 1, 0,
                        0, 1, 0,

                        0, 1, 0,
                        0, 1, 0,
                        0, 1, 0,
                        0, 1, 0,

                        -1, 0, 0,
                        -1, 0, 0,
                        -1, 0, 0,
                        -1, 0, 0,

                        -1, 0, 0,
                        -1, 0, 0,
                        1, 0, 0,
                        1, 0, 0,

                        1, 0, 0,
                        1, 0, 0,
                        1, 0, 0,
                        1, 0, 0,

                        -1, 0, 0,
                        -1, 0, 0,
                        -1, 0, 0,
                        -1, 0, 0,

                        -1, 0, 0,
                        -1, 0, 0,

                        -1, 0, 0,
                        -1, 0, 0,
                        -1, 0, 0,

                        -1, 0, 0,
                        -1, 0, 0,
                        -1, 0, 0,

                    ]
                },
                vTex: {
                    numComponents: 3,
                    data:
                        [
                            0, 0,
                            1, 0,
                            1, 1,
                            0, 1
                        ]
                }
            };
            buffers = twgl.createBufferInfoFromArrays(drawingState.gl, arrays);
        }

    };
    scoreboard.prototype.draw = function (drawingState) {

        var modelM = twgl.m4.scaling([this.size, this.size, this.size]);
        modelM = twgl.m4.rotationY(Math.PI / 2);
        twgl.m4.setTranslation(modelM, this.position, modelM);
        var normalMatrix = [1, 1, 0, 0, 1, 1, 1, 0, 1];
        window.gl = drawingState.gl;
        gl.useProgram(shaderProgram.program);
        twgl.setBuffersAndAttributes(gl, shaderProgram, buffers);
        twgl.setUniforms(shaderProgram,
            {
                view: drawingState.view,
                proj: drawingState.proj,
                lightdir: drawingState.sunDirection,
                cubecolor: this.color,
                model: modelM,
                normalMatrix: normalMatrix
            });
        twgl.drawBufferInfo(gl, gl.TRIANGLES, buffers);
    };
    scoreboard.prototype.center = function (drawingState) {
        return this.position;
    }

})();

grobjects.push(new scoreboard("Scoreboard CF", [0, 1, 3], 1, [1.0, 1.0, 1.0]));
grobjects.push(new scoreboard("Scoreboard LF", [2, 1, 2], 1, [1.0, 1.0, 1.0]));
grobjects.push(new scoreboard("Scoreboard RF", [-2, 1, 2], 1, [1.0, 1.0, 1.0]));


